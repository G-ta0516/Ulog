package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Question;
import model.RegisterLogic;
import model.User;

@WebServlet("/RegisterUser")
@MultipartConfig
public class RegisterUser extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
//		フォワード先
		String forwardPath = null;
		String action = request.getParameter("action");
		if (action == null) {
			forwardPath = "/WEB-INF/jsp/registerForm.jsp";
		} else if (action.equals("done")) {
			HttpSession session = request.getSession();
			User registerUser = (User) session.getAttribute("registerUser");
			// 登録処理の呼び出し
			RegisterLogic logic = new RegisterLogic();
			boolean registeration = logic.execute(registerUser);
			// 不要なセッションスコープ内のインスタンス削除
			//session.removeAttribute("registerUser");

			// 新規登録出来た場合(IDが登録済みではなかった場合)
			if (registeration) {
				Question question=new Question();
				request.setAttribute("question",question);
				forwardPath = "/WEB-INF/jsp/questionForm.jsp";
			} else {// 登録済みだった場合
				String errorMsg = "登録済みのIDです";
				// エラーメッセージをスコープに保存
				request.setAttribute("errorMsg", errorMsg);
				// フォワード
				forwardPath = "/WEB-INF/jsp/registerConfirm.jsp";
			}

		}
		RequestDispatcher dispatcher = request.getRequestDispatcher(forwardPath);
		dispatcher.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// リクエストパラメータの取得
		request.setCharacterEncoding("UTF-8");
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String pass = request.getParameter("pass");
		String age = request.getParameter("age");
		String gen = request.getParameter("gen");
		// リクエストパラメータのチェック（エラー）
		String errorMsg = "";
		// エラーメッセージをリクエストスコープに保存
		request.setAttribute("errorMsg", errorMsg);
		// 登録するユーザーの情報を設定
		User registerUser = new User();
		registerUser.setId(id);
		registerUser.setName(name);
		registerUser.setPass(pass);
		registerUser.setAge(age);
		registerUser.setGen(gen);

		// セッションスコープに登録ユーザー保存
		HttpSession session = request.getSession();
		session.setAttribute("registerUser", registerUser);

		// フォワード
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/registerConfirm.jsp");
		dispatcher.forward(request, response);
	}
}
