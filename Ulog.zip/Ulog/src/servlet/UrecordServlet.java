package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Advise;
import model.PostURecord;
import model.User;

@WebServlet("/UrecordServlet")
public class UrecordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
//		U記録画面にフォワード
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/uRecord.jsp");
		dispatcher.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		// リクエストパラメータ(記録)の取得
		String datetime = request.getParameter("datetime");
		String condition = request.getParameter("condition");
		String color = request.getParameter("color");
		String memo = request.getParameter("memo");
		
		datetime = datetime.replace("T", " ");

		// U記録を記録リストに追加
		User user = new User(datetime, condition, color, memo);

		HttpSession session = request.getSession();
		User loginUser = (User) session.getAttribute("loginUser");
		user.setPid(loginUser.getPid());

		PostURecord postURecord = new PostURecord();
		postURecord.execute(user);

		// アドバイスのチョイス
		Advise advise = new Advise();
		advise.execute(user);

//		U記録をリクエストスコープに保存
		request.setAttribute("uRecord", user);

//		記録完了画面にフォワード
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/uRecordOK.jsp");
		dispatcher.forward(request, response);

	}

}
