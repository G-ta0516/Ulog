package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.GetURecordList;
import model.UrecordSerch;
import model.User;

@WebServlet("/Main")
public class Main extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// 今月の取得
		String thisMonth = UrecordSerch.thisMonth();
		request.setAttribute("month", thisMonth);

		// U記録を取得して、リクエストスコープに保存
		thisMonth += "%";

		User user = new User();
		HttpSession session = request.getSession();
		User loginUser = (User) session.getAttribute("loginUser");
		user.setPid(loginUser.getPid());

		GetURecordList getURecordList = new GetURecordList();
		List<User> uRecordList = getURecordList.execute(thisMonth, user);
		request.setAttribute("uRecordList", uRecordList);

		// マイページ画面にフォワード
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/main.jsp");
		dispatcher.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// 選択された年月を取得
		String yearMonth = request.getParameter("yearMonth");
		String month = UrecordSerch.month(yearMonth);
		request.setAttribute("month", month);

		// U記録を取得して、リクエストスコープに保存
		month += "%";

		User user = new User();
		HttpSession session = request.getSession();
		User loginUser = (User) session.getAttribute("loginUser");
		user.setPid(loginUser.getPid());

		GetURecordList getURecordList = new GetURecordList();
		List<User> uRecordList = getURecordList.execute(month, user);
		request.setAttribute("uRecordList", uRecordList);

		// マイページ画面にフォワード
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/main.jsp");
		dispatcher.forward(request, response);

	}

}
