package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.LoginDAO;
import model.GetURecordList;
import model.UrecordSerch;
import model.User;

@WebServlet("/Login")
public class Login extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/main.jsp");
		dispatcher.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String id = request.getParameter("id");
		String pass = request.getParameter("pass");

		User user = new User();

		user.setId(id);

		LoginDAO dao = new LoginDAO();
		dao.findByLogin(user);

		boolean lock;
		if (pass.equals(user.getPass())) {
			lock = true;
		} else {
			lock = false;
		}

		if (lock) {
			HttpSession session = request.getSession();
			session.setAttribute("loginUser", user);
			
			//今月の取得
			String thisMonth = UrecordSerch.thisMonth();
			request.setAttribute("month", thisMonth);
			
			//U記録を取得して、リクエストスコープに保存
			thisMonth += "%";
			
			GetURecordList getURecordList = new GetURecordList();
			List<User> uRecordList = getURecordList.execute(thisMonth,user);
			request.setAttribute("uRecordList", uRecordList);
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/main.jsp");
			dispatcher.forward(request, response);
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/false.jsp");
		dispatcher.forward(request, response);

	}

}
