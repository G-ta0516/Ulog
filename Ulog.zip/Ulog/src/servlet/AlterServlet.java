package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.RegisterLogic;
import model.User;


@WebServlet("/AlterServlet")
public class AlterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String forwardPath = null;
		String action = request.getParameter("action");
		if (action == null) {
//			forwardPath = "/WEB-INF/jsp/alter.jsp";
			RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/alter.jsp");
			dispatcher.forward(request, response);
		} else if (action.equals("done")) {
			HttpSession session = request.getSession();
			User registerUser = (User) session.getAttribute("registerUser");
			// 登録処理の呼び出し
//			
			RegisterLogic logic = new RegisterLogic();
			boolean registeration = logic.execute2(registerUser);

			// 新規登録出来た場合(IDが登録済みではなかった場合)
			if (registeration) {
				RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/alterDone.jsp");
				dispatcher.forward(request, response);
//				forwardPath = "/WEB-INF/jsp/alterDone.jsp";
			} else {// 登録済みだった場合
				String errorMsg = "登録済みのIDです";
				// エラーメッセージをスコープに保存
				request.setAttribute("errorMsg", errorMsg);
				// フォワード
				RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/alterConfirm.jsp");
				dispatcher.forward(request, response);
//				forwardPath = "/WEB-INF/jsp/registerConfirm.jsp";
			}
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String pass = request.getParameter("pass");
		String age = request.getParameter("age");
		String gen = request.getParameter("gen");
		// リクエストパラメータのチェック（エラー）
		String errorMsg = "";
		// エラーメッセージをリクエストスコープに保存
		request.setAttribute("errorMsg", errorMsg);
		// 登録するユーザーの情報を設定
		HttpSession session = request.getSession();
		User loginUser = (User)session.getAttribute("loginUser");
		User registerUser = new User();
		registerUser=loginUser;
		registerUser.setId(id);
		registerUser.setName(name);
		registerUser.setPass(pass);
		registerUser.setAge(age);
		registerUser.setGen(gen);
		
		session.setAttribute("registerUser", registerUser);

		// フォワード
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/alterConfirm.jsp");
		dispatcher.forward(request, response);
	}

}
