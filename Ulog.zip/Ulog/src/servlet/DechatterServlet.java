package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Dechatter;
import model.DechatterEVLogic;
import model.GetDechatterListLogic;
import model.PostDechatterLogic;
import model.User;

@WebServlet("/DechatterServlet")
public class DechatterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		String action = request.getParameter("action");
		String index = request.getParameter("index");

		Dechatter dechatter = new Dechatter();

//		つぶやきリスト取得
		GetDechatterListLogic getDechatterListLogic = new GetDechatterListLogic();
		List<Dechatter> dechatterList = getDechatterListLogic.execute(dechatter);
		request.setAttribute("dechatterList", dechatterList);

		HttpSession session = request.getSession();
		User loginUser = (User) session.getAttribute("loginUser");
		User user = new User();
		user.setPid(loginUser.getPid());

		if (action != null && action.length() != 0 && index != null && index.length() != 0) {

			DechatterEVLogic dechatterEVLogic = new DechatterEVLogic();
			if (action.equals("good")) {
				dechatterEVLogic.good(dechatterList.get(Integer.parseInt(index)));
			} else if (action.equals("care")) {
				dechatterEVLogic.care(dechatterList.get(Integer.parseInt(index)));
				
			} else if (action.equals("delete") && dechatterList.size() > 0) {
				dechatter = dechatterList.get(Integer.parseInt(index));
				dechatterEVLogic.check(dechatter);
				if (user.getPid() == dechatter.getPid()) {
					dechatterEVLogic.remove(dechatterList.get(Integer.parseInt(index)));
				}
				dechatter.setPid(0);
			}

			dechatterList = getDechatterListLogic.execute(dechatter);

//			つぶやきリストをリクエストスコープに保存
			request.setAttribute("dechatterList", dechatterList);

			RequestDispatcher dis = request.getRequestDispatcher("/WEB-INF/jsp/dechatter.jsp");
			dis.forward(request, response);
		}

		RequestDispatcher dis = request.getRequestDispatcher("/WEB-INF/jsp/dechatter.jsp");
		dis.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//		リクエストパラメータの取得
		request.setCharacterEncoding("UTF-8");
		String comment = request.getParameter("comment");

		User user = new User();

//		入力値チェック
		if (comment != null && comment.length() != 0) {

//			つぶやきをつぶやきリストに追加
			user.setComment(comment);

			HttpSession session = request.getSession();
			User loginUser = (User) session.getAttribute("loginUser");
			user.setName(loginUser.getName());
			user.setPid(loginUser.getPid());

			PostDechatterLogic postDechatterLogic = new PostDechatterLogic();
			postDechatterLogic.execute(user);

		} else {
//			エラーメッセージをリクエストスコープに保存
			request.setAttribute("errorMsg", "つぶやきが入力されていません");

		}

//		つぶやきリストを取得して、リクエストスコープに保存
		Dechatter dechatter = new Dechatter();
		GetDechatterListLogic getDechatterListLogic = new GetDechatterListLogic();
		List<Dechatter> dechatterList = getDechatterListLogic.execute(dechatter);
		request.setAttribute("dechatterList", dechatterList);

//		フォワード
		RequestDispatcher dis = request.getRequestDispatcher("/WEB-INF/jsp/dechatter.jsp");
		dis.forward(request, response);

	}

}
