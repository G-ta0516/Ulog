package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Question;
import model.QuestionLogic;
import model.User;

@WebServlet("/Uquestion")
public class Uquestion extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/registerDone.jsp");
		dispatcher.forward(request, response);
	}
	ArrayList<String> q=new ArrayList<>();
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String[] q0= request.getParameterValues("question1");
		String[] q1= request.getParameterValues("question2");
		String[] q2= request.getParameterValues("question3");
		String[] q3= request.getParameterValues("question4");
		String[] q4= request.getParameterValues("question5");
		
		try {
		if(q0[0]==null||q1[0]==null||q2[0]==null||q3[0]==null||q4[0]==null) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/questionForm.jsp");
			dispatcher.forward(request, response);
		}
		}catch(NullPointerException e){
			Question question=new Question();
			question.setA(1);
			request.setAttribute("question",question);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/questionForm.jsp");
			dispatcher.forward(request, response);
		}

		for(int i=0;i<q0.length;i++) {
			
			q.add(q0[i]);
		}
		for(int i=0;i<q1.length;i++) {
		
			q.add(q1[i]);
		}
		for(int i=0;i<q2.length;i++) {
			
			q.add(q2[i]);
		}		
		for(int i=0;i<q3.length;i++) {
		
			q.add(q3[i]);
		}
		for(int i=0;i<q4.length;i++) {
			q.add(q4[i]);
		}
		int a=0;
		int b=0;
		int c=0;
		int d=0;
		int e=0;
		int f=0;
		
		for(String s:q) {
			if(s.equals("1")) {
				a +=1;
			}
			else if(s.equals("2")) {
				b +=1;
			}
			else if(s.equals("3")) {
				c +=1;
			}
			else if(s.equals("4")) {
				d +=1;
			}
			else if(s.equals("5")) {
				e +=1;
			}
			else if(s.equals("6")) {
				f +=1;
			}
		}
		
		Question question = new Question();
		question.setA(a);
		question.setB(b);
		question.setC(c);
		question.setD(d);
		question.setE(e);
		question.setF(f);
		
		//セッションスコープに保存さているユーザー名取得
		HttpSession session = request.getSession();
		User registerUser = (User) session.getAttribute("registerUser");
		
		//セッションスコープから取得したユーザー名をqustion.User_nameに保存
		question.setUser_name(registerUser.getId());
		
		//QuestionLogicの中の処理をしてもらう文
		QuestionLogic ql=new QuestionLogic(question);
		
		request.setAttribute("question",question);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/questionfin.jsp");
		dispatcher.forward(request, response);
	}
	
	

}
