package servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Advise;
import model.GetURecordDay;
import model.User;

@WebServlet("/UrecordViewServlet")
public class UrecordViewServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		// リクエストパラメータ(記録)の取得
		String datetime = request.getParameter("action");

		User user = new User();
		HttpSession session = request.getSession();
		User loginUser = (User) session.getAttribute("loginUser");
		user.setPid(loginUser.getPid());

		// U記録を取得して、リクエストスコープに保存
		GetURecordDay getURecordDay = new GetURecordDay();
		List<User> uRecordDay = getURecordDay.execute(datetime, user);
		
		Advise advise = new Advise();
		advise.execute(uRecordDay.get(0));

		request.setAttribute("uRecordDay", uRecordDay);

		// 記録完了画面にフォワード
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/jsp/uRecordView.jsp");
		dispatcher.forward(request, response);

	}

}
