package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.User;

public class CheckDAO {
	
	private final String JDBC_URL = "jdbc:mysql://localhost:3306/"
			+ "Ulog?characterEncoding=UTF-8&serverTimezone=Asia/Tokyo";
	private final String DB_USER = "root";
	private final String DB_PASS = "root";
	public User findByCheck(User user) {

		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
			String sql = "SELECT USER_ID,PASS,GENDER,AGE,USER_NAME,TYPE FROM USERS WHERE ID =?";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setInt(1, user.getPid());

			ResultSet rs = pStmt.executeQuery();

			if (rs.next()) {
				String pass = rs.getString("PASS");
				String user_name = rs.getString("USER_NAME");
				String user_id = rs.getString("USER_ID");
				String gender = rs.getString("GENDER");
				String age = rs.getString("AGE");
				String type = rs.getString("TYPE");

				user.setId(user_id);
				user.setPass(pass);
				user.setName(user_name);
				user.setGen(gender);
				user.setAge(age);
				user.setType(type);
				
				
				
			}

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return user;
	}
}
