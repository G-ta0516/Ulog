package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.User;

public class LoginDAO {
	private final String JDBC_URL = "jdbc:mysql://localhost:3306/"
			+ "Ulog?characterEncoding=UTF-8&serverTimezone=Asia/Tokyo";
	private final String DB_USER = "root";
	private final String DB_PASS = "root";

	public User findByLogin(User user) {

		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
			String sql = "SELECT ID,PASS,USER_NAME FROM USERS WHERE USER_ID =?";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setString(1, user.getId());

			ResultSet rs = pStmt.executeQuery();

			if (rs.next()) {
				int id = rs.getInt("ID");
				String pass = rs.getString("PASS");
				String user_name = rs.getString("USER_NAME");
				user.setPid(id);
				user.setPass(pass);
				user.setName(user_name);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return user;
	}
	

	public boolean findByAccount(User user) {
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
			String sql = "SELECT USER_ID FROM USERS WHERE USER_ID =?&& ID!=?";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setString(1, user.getId());
			pStmt.setInt(2, user.getPid());

			ResultSet rs = pStmt.executeQuery();

			if (rs.next()) {
				return true;

			}

		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return false;
	}

	public boolean create(User user) {
		// データベースに接続
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {

			// INSERT文の準備
			String sql = "INSERT INTO USERS(USER_ID,PASS,GENDER,AGE,USER_NAME) VALUES(?,?,?,?,?)";
			PreparedStatement pStmt = conn.prepareStatement(sql);

			// INSERT文中の「?」に使用する値を設定しSQLを完成
			pStmt.setString(1, user.getId());// 1つ目の「?」
			pStmt.setString(2, user.getPass());// 2つ目の「?」
			pStmt.setString(3, user.getGen());// 3つ目の「?」
			pStmt.setString(4, user.getAge());// 4つ目の「?」
			pStmt.setString(5, user.getName());// 5つ目の「?」

			// INSERTを実行（resultには正常終了した場合は「1」、正常終了しなかった場合は「0」が代入される）
			int result = pStmt.executeUpdate();
			if (result != 1) {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
		public boolean create2(User user) {
		// データベースに接続
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {

			// INSERT文の準備
			String sql = "UPDATE USERS SET USER_ID=?,PASS=?,GENDER=?,AGE=?,USER_NAME=? WHERE ID =?";
			PreparedStatement pStmt = conn.prepareStatement(sql);

			// INSERT文中の「?」に使用する値を設定しSQLを完成
			pStmt.setString(1, user.getId());// 1つ目の「?」
			pStmt.setString(2, user.getPass());// 2つ目の「?」
			pStmt.setString(3, user.getGen());// 3つ目の「?」
			pStmt.setString(4, user.getAge());// 4つ目の「?」
			pStmt.setString(5, user.getName());// 5つ目の「?」
			pStmt.setInt(6, user.getPid());// 6つ目の「?」

			// INSERTを実行（resultには正常終了した場合は「1」、正常終了しなかった場合は「0」が代入される）
			int result = pStmt.executeUpdate();
			if (result != 1) {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
}
