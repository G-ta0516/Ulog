package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Dechatter;
import model.User;

public class DechatterDAO {
//	データベース接続に使用する情報
	private final String JDBC_URL = "jdbc:mysql://localhost:3306/"
			+ "ulog?characterEncoding=UTF-8&serverTimezone=Asia/Tokyo";
	private final String DB_USER = "root";
	private final String DB_PASS = "root";

	public List<Dechatter> findAll(Dechatter dechatter) {
		List<Dechatter> dechatterList = new ArrayList<>();

		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
//			select文の準備
			String sql = "SELECT DECHATTER_ID, COMMENT, CREATE_AT, GOOD, CARE,NAME FROM DECHATTER ORDER BY DECHATTER_ID DESC";
			PreparedStatement pStmt = conn.prepareStatement(sql);

//			selectを実行
			ResultSet rs = pStmt.executeQuery();

//			select文の結果をArrayListに格納
			while (rs.next()) {
				int id = rs.getInt("DECHATTER_ID");
				String comment = rs.getString("COMMENT");
				String create_at = rs.getString("CREATE_AT");
				int good = rs.getInt("GOOD");
				int care = rs.getInt("CARE");
				String userName = rs.getString("NAME");
				dechatter = new Dechatter(id, comment, create_at, good, care, userName);
				dechatterList.add(dechatter);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return dechatterList;
	}

	public List<Dechatter> findAll() {
		List<Dechatter> dechatterList = new ArrayList<>();

		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
//			select文の準備
			String sql = "SELECT DECHATTER_ID, COMMENT, CREATE_AT, GOOD, CARE, (SELECT USER_NAME FROM USERS WHERE USER_ID = ?) AS USER_NAME FROM DECHATTER ORDER BY DECHATTER_ID DESC";
			PreparedStatement pStmt = conn.prepareStatement(sql);

//			selectを実行
			ResultSet rs = pStmt.executeQuery();

//			select文の結果をArrayListに格納
			while (rs.next()) {
				int id = rs.getInt("DECHATTER_ID");
				String comment = rs.getString("COMMENT");
				String create_at = rs.getString("CREATE_AT");
				int good = rs.getInt("GOOD");
				int care = rs.getInt("CARE");
				String user_name = rs.getString("USER_NAME");
				Dechatter dechatter = new Dechatter(id, comment, create_at, good, care, user_name);
				dechatterList.add(dechatter);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return dechatterList;
	}

	public boolean create(User user) {
//		データベース接続
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {

//			insert文の準備（idは自動連番なので指定しなくてよい）
			String sql = "insert into dechatter(id,name,comment) values(?,?,?)";
			PreparedStatement pStmt = conn.prepareStatement(sql);

//			insert文中の「？」に使用する値を設定しSQLを完成
			pStmt.setInt(1, user.getPid());
			pStmt.setString(2, user.getName());
			pStmt.setString(3, user.getComment());

//			insert文を実行（resultには追加された行数が代入）
			int result = pStmt.executeUpdate();
			if (result != 1) {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean updateGood(Dechatter dechatter) {
//		データベースへ接続
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
//			UPDATE文の準備
			String sql = "UPDATE DECHATTER SET GOOD=? WHERE DECHATTER_ID =?";
			PreparedStatement pStmt = conn.prepareStatement(sql);

//			UPDATE文中の「？」に使用する値を設定しSQLを完成
			pStmt.setInt(1, dechatter.getGood());
			pStmt.setInt(2, dechatter.getDechatter_id());

//			update文を実行
			int result = pStmt.executeUpdate();
			if (result != 1) {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean updateCare(Dechatter dechatter) {
//		データベースへ接続
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
//			UPDATE文の準備
			String sql = "UPDATE DECHATTER SET CARE=? WHERE DECHATTER_ID =?";
			PreparedStatement pStmt = conn.prepareStatement(sql);

//			UPDATE文中の「？」に使用する値を設定しSQLを完成
			pStmt.setInt(1, dechatter.getCare());
			pStmt.setInt(2, dechatter.getDechatter_id());

//			update文を実行
			int result = pStmt.executeUpdate();
			if (result != 1) {
				return false;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public boolean remove(Dechatter dechatter) {
//		データベースへ接続
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {
//			DELETE文の準備
			String sql = "DELETE FROM DECHATTER WHERE DECHATTER_ID=?";
			PreparedStatement pStmt = conn.prepareStatement(sql);

//			delete文中の「？」に使用する値を設定しSQLを完成
			pStmt.setInt(1, dechatter.getDechatter_id());

//			delete文を実行
			int result = pStmt.executeUpdate();
			return (result == 1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public void check(Dechatter dechatter) {
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {

			String sql = "SELECT ID FROM DECHATTER WHERE DECHATTER_ID =?";
			PreparedStatement pStmt = conn.prepareStatement(sql);

			pStmt.setInt(1, dechatter.getDechatter_id());

//			selectを実行
			ResultSet rs = pStmt.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("ID");
				dechatter.setPid(id);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
