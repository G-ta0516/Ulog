package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.User;

public class UrecordDAO {

	// データベースに接続使用する情報
	private final String JDBC_URL = "jdbc:mysql://localhost:3306/"
			+ "ulog?characterEncoding=UTF8&serverTimezone=Asia/Tokyo";
	private final String DB_USER = "root";
	private final String DB_PASS = "root";


	// 月のU記録の取得
	public List<User> serchMonth(String day, User user) {

		List<User> uRecordList = new ArrayList<>();

		// データベースへ接続
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {

			// SELECT文を準備
			String sql = "SELECT DATETIME, UCONDITION, COLOR FROM URECORD WHERE ID = ? AND DATETIME LIKE ? ORDER BY DATETIME";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			
			pStmt.setInt(1, user.getPid());
			pStmt.setString(2, day);

			// SELECTを実行し、取得
			ResultSet rs = pStmt.executeQuery();

			while (rs.next()) {

				// レコードの値を取得
				String datetime = rs.getString("datetime");
				String ucondition = rs.getString("ucondition");
				String color = rs.getString("color");
				// 取得した値をUrecordインスタンスに格納
				User uRecord = new User(datetime, ucondition, color);
				// ArrayListインスタンスにUrecordインスタンスを追加する
				uRecordList.add(0, uRecord);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return uRecordList;

	}

	// 日のU記録の取得
	public List<User> day(String day, User user) {

		List<User> uRecordList = new ArrayList<>();

		// データベースへ接続
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {

			// SELECT文を準備
			String sql = "SELECT DATETIME, UCONDITION, COLOR, MEMO FROM URECORD WHERE ID = ? AND DATETIME = ?";
			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setInt(1, user.getPid());
			pStmt.setString(2, day);

			// SELECTを実行し、取得
			ResultSet rs = pStmt.executeQuery();

			while (rs.next()) {

				// レコードの値を取得
				String datetime = rs.getString("datetime");
				String ucondition = rs.getString("ucondition");
				String color = rs.getString("color");
				String memo = rs.getString("memo");
				// 取得した値をUrecordインスタンスに格納
				User uRecord = new User(datetime, ucondition, color, memo);
				// ArrayListインスタンスにUrecordインスタンスを追加する
				uRecordList.add(uRecord);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return uRecordList;

	}

	// U記録追加
	public boolean create(User user) {

		// データベースへ接続
		try (Connection conn = DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASS)) {

			// INSERT文を準備(必要なものだけ)
			String sql = "INSERT INTO URECORD (ID, DATETIME, UCONDITION, COLOR, MEMO) VALUES (?, ?, ?, ?, ?)";

			PreparedStatement pStmt = conn.prepareStatement(sql);

			pStmt.setInt(1, user.getPid());
			pStmt.setString(2, user.getDatetime());
			pStmt.setString(3, user.getUcondition());
			pStmt.setString(4, user.getColor());
			pStmt.setString(5, user.getMemo());

			int result = pStmt.executeUpdate();

			if (result != 1) {

				return false;

			}

		} catch (SQLException e) {

			e.printStackTrace();

		}

		return true;

	}

}
