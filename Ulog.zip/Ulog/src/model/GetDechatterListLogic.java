package model;

import java.util.List;

import dao.DechatterDAO;

public class GetDechatterListLogic {
	public List<Dechatter> execute(Dechatter dechatter) {
		DechatterDAO dao = new DechatterDAO();
		List<Dechatter> dechatterList = dao.findAll(dechatter);
		return dechatterList;
	}

	public List<Dechatter> execute2() {
		DechatterDAO dao = new DechatterDAO();
		List<Dechatter> dechatterList = dao.findAll();
		return dechatterList;
	}

}
