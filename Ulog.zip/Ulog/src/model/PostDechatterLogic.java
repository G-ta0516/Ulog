package model;

import dao.DechatterDAO;

public class PostDechatterLogic {
	public void execute (User user) {
		DechatterDAO dao = new DechatterDAO();
		dao.create(user);
	}

}
