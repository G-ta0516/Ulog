package model;

import java.util.List;

import dao.UrecordDAO;

public class GetURecordList {

	public List<User> execute(String day, User user) {

		UrecordDAO dao = new UrecordDAO();
		List<User> uRecordList = dao.serchMonth(day, user);
		return uRecordList;

	}

}
