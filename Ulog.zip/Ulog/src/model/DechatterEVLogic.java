package model;

import dao.DechatterDAO;

public class DechatterEVLogic {
	public void good(Dechatter dechatter) {
		int count = dechatter.getGood();
		dechatter.setGood(count + 1);
		DechatterDAO dao = new DechatterDAO();
		dao.updateGood(dechatter);
	}

	public void care(Dechatter dechatter) {
		int count = dechatter.getCare();
		dechatter.setCare(count + 1);
		DechatterDAO dao = new DechatterDAO();
		dao.updateCare(dechatter);
	}

	public void remove(Dechatter dechatter) {
		DechatterDAO dao = new DechatterDAO();
		dao.remove(dechatter);
	}
	
	public void check(Dechatter dechatter) {
		DechatterDAO dao = new DechatterDAO();
		dao.check(dechatter);
	}

}
