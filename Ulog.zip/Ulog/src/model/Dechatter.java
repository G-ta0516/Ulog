package model;

import java.io.Serializable;

public class Dechatter implements Serializable {
	private int dechatter_id; 		// id
	private int Pid;					//管理用ID
	private String user_id;			//ユーザーID
	private String userName;		// ユーザー名
	private String comment;		// つぶやき内容
	private String create_at; 		// つぶやいた日時
	private int good; 				// いいね
	private int care; 					// 大丈夫

	public Dechatter() {
		good = 0;
		care = 0;
	}

	public Dechatter(int dechatter_id, String comment, String create_at, int good, int care, String userName) {
		this.dechatter_id = dechatter_id;
		this.comment = comment;
		this.create_at = create_at;
		this.good = good;
		this.care = care;
		this.userName = userName;
	}
	
	public int getDechatter_id() {
		return dechatter_id;
	}

	public int getPid() {
		return Pid;
	}

	public void setPid(int pid) {
		Pid = pid;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getCreate_at() {
		return create_at;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getGood() {
		return good;
	}

	public void setGood(int good) {
		this.good = good;
	}

	public int getCare() {
		return care;
	}

	public void setCare(int care) {
		this.care = care;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

}