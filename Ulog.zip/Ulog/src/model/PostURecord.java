package model;

import dao.UrecordDAO;

public class PostURecord {
	
	public void execute(User user) {
		
		UrecordDAO dao = new UrecordDAO();
		dao.create(user);
		
	}

}
