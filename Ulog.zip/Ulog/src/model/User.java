package model;

import java.io.Serializable;

public class User implements Serializable {
	private int pid;
	private String id;
	private String name;
	private String pass;
	private String age;
	private String gen;
	private String type;

//	でちゃったー用
	private String comment;

//	U記録用
	private String datetime;
	private String ucondition;
	private String color;
	private String memo;
	private String advise;

	public User() {
	}

	public User(String datetime, String ucondition, String color) {
		this.datetime = datetime;
		this.ucondition = ucondition;
		this.color = color;
	}

	public User(String datetime, String ucondition, String color, String memo) {
		this.datetime = datetime;
		this.ucondition = ucondition;
		this.color = color;
		this.memo = memo;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getGen() {
		return gen;
	}

	public void setGen(String gen) {
		this.gen = gen;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getDatetime() {
		return datetime;
	}

	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}

	public String getUcondition() {
		return ucondition;
	}

	public void setUcondition(String ucondition) {
		this.ucondition = ucondition;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getAdvise() {
		return advise;
	}

	public void setAdvise(String advise) {
		this.advise = advise;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	

}
