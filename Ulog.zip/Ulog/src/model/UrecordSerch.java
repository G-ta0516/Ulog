package model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class UrecordSerch {
	
	public static String thisMonth() {
		
		LocalDate localDate = LocalDate.now();
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		String today = localDate.format(dateTimeFormatter);
		String result = today.substring(0, 7);
		
		return result;
		
	}
	
	public static String month(String month) {
		
	String result = month.substring(0, 7);
		
		return result;
	}

}
