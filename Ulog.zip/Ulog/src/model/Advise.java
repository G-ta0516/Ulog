package model;

public class Advise {

	public void execute(User user) {

		String condition = user.getUcondition();
		String color = user.getColor();

		String advise1 = "";
		String advise2 = "";

		// 状態のアドバイス
		if (condition.equals("ばなな")) {

			advise1 = "ばなな状の便は健康な便です。<br>";

		} else if (condition.equals("びしゃびしゃ")) {

			advise1 = "下痢です。水様性の場合、粘液、血液、膿などが混じると細菌性赤痢や伝染性下痢、アレルギー性などが考えられます。<br>";

		} else if (condition.equals("ころころ")) {

			advise1 = "ウサギの糞のようなコロコロとした便が出る場合は、大腸のどこかがけいれんしているけいれん性便秘が考えられます。<br>";

		} else if (condition.equals("太くてかたい")) {

			advise1 = "排便時に便柱が太くて硬い場合は、大腸の運動が低下している弛緩性便秘が考えられます。<br>";

		} else if (condition.equals("かたくて断片的")) {

			advise1 = "かたくて断片的な便はたびたび便意をこらえることによって、直腸の感受性が低下して起こります。<br>";

		}

		// 色のアドバイス
		if (color.equals("おうど色")) {

			advise2 += "正常な便の色調です。これは胆汁色素ビリルビンによると考えられています。";

		} else if (color.equals("黄色")) {

			advise2 += "黄色い便は高度の下痢便などで見られます。牛乳の多飲、ダイオウ末、センナの下剤の服用や脂肪便のときでも見られます。";

		} else if (color.equals("茶色")) {

			advise2 += "茶色の便は食べ過ぎ、飲み過ぎです。";

		} else if (color.equals("こげ茶色")) {

			advise2 += "こげ茶色の便は便秘の時や肉類の多い食事で見られます。また、ココアやチョコレートを大量に食べる人でもこの様な色になります。";

		} else if (color.equals("黒色")) {

			advise2 += "黒色の便は上部消化管の出血でコールタールに似ているため、タール便ともいいます。50～75ML以上の出血で便を黒色にし、1000ML以上の出血は2～3日続いてタール便となります。<br>また、イカ墨料理、ビスマス剤、鉄剤、薬用炭も黒色便になります。";

		} else if (color.equals("緑色")) {

			advise2 += "母乳の赤ちゃんの便や緑色を呈したクロロフィルを多く含む緑色野菜を大量に食べる人の便は、緑色になります。";

		} else if (color.equals("赤色")) {

			advise2 += "赤黒いゼリーのようなものは、腸重積の疑いがあります。";

		} else if (color.equals("白色")) {

			advise2 += "白色の便は胆汁の出が悪いか、胃透視時のバリウムによるものです。腸結核、膵疾患でもこの様な色になります。";

		}

		String advise = advise1 + advise2;
		user.setAdvise(advise);

	}

}
