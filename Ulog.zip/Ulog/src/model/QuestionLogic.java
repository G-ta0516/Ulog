package model;

import dao.QuestionDAO;

public class QuestionLogic {

	public QuestionLogic(Question question) {

		int a = question.getA();
		int b = question.getB();
		int c = question.getC();
		int d = question.getD();
		int e = question.getE();
		int f = question.getF();
		int[] x = { a, b, c, d, e, f };
		int max = 0;

		for (int i = 0; i < x.length; i++) {
			max = Math.max(x[i], max);
		}
		if (max == a) {
			question.setType("便秘タイプ１");
		} else if (max == b) {
			question.setType("便秘タイプ２");
		} else if (max == c) {
			question.setType("混合型タイプ");
		} else if (max == d) {
			question.setType("健康タイプ");
		} else if (max == e) {
			question.setType("軟便タイプ");
		} else if (max == f) {
			question.setType("下痢タイプ");
		}
		QuestionDAO questionDAO = new QuestionDAO();
		questionDAO.create(question);
	}
}
