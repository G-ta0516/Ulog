package model;
import dao.LoginDAO;

public class RegisterLogic {
	public boolean execute(User user) {
		LoginDAO dao = new LoginDAO();
		//IDが登録済みか確認
		boolean registered = dao.findByAccount(user);
		//登録処理
		if(!registered) {
			dao.create(user);
			return true;
		}else {
			return false;
		}
	}
	public boolean execute2(User user) {
		LoginDAO dao = new LoginDAO();
		//IDが登録済みか確認
		boolean registered = dao.findByAccount(user);
		//登録処理
		if(!registered) {
			dao.create2(user);
			return true;
		}else {
			return false;
		}
	}
}
