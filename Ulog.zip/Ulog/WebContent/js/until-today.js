$(function(){
    var dtToday= new Date();
    var year= dtToday.getFullYear();
    var month= dtToday.getMonth() + 1;
    var day= dtToday.getDate();
    var hour = dtToday.getHours();
    var minute = dtToday.getMinutes();
    if(month < 10)
        month= '0' + month.toString();
    if(day < 10)
        day= '0' + day.toString();
    if(hour < 10)
        hour= '0' + hour.toString();
    if(minute < 10)
        minute= '0' + minute.toString();
    var maxDate= year + '-' + month + '-' + day + '\T' + hour + ':' + minute;
    $('#until-today').attr('max', maxDate);
});